"""Exercise the exact Workspace vector mutation grader with real fixtures.

This is an isolated adverse observation, not a certification or production tool.
"""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import secrets
import subprocess
import sys

root = Path(__file__).resolve().parent
native = root / 'native'
source = native / 'tools/verify_federation_vector.py'
harness = native / 'tests/test_verify_federation_vector_mutations.py'
expected = {
    'tests/test_verify_federation_vector_mutations.py': '19d941b52b03e9b1236758d59c4e965ed5137d2b',
    'tests/test_verify_federation_vector.py': 'b536cf8398d03bbe607d56e88ccd111a14c99c2c',
    'tools/verify_federation_vector.py': 'bb7b974ce09481e861baf95fefce85ba5b20d394',
    'tools/check_workspace.py': '52619edbc3612ae4fadb225639c2c102d6a0facb',
    'tools/verify_pins.py': 'b05916e54c34cffc95601b313bc1c154d99ccbcc',
    'tools/verify_canonical_inputs.py': '1718c34179afb5c89526b5002bb59b94eb0b945e',
}
manifest = []
for name, oid in expected.items():
    raw = (native / name).read_bytes()
    observed = hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()
    if observed != oid:
        raise ValueError('native Git blob mismatch: ' + name)
    manifest.append({'path': name, 'git_blob_sha1': oid, 'sha256': hashlib.sha256(raw).hexdigest()})
(root / 'source-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')

text = source.read_text()
weakening = "for row in workspace['canonical']:"
insertion = 'def required_remote_commits(snapshot: dict, workspace: dict, locks: dict) -> list[dict]:\n'
if text.count(weakening) != 1 or text.count(insertion) != 1:
    raise ValueError('expected native mutation anchors changed')
spoof = ("    import unittest.mock\n"
         "    result = unittest.mock.MagicMock()\n"
         "    result.__len__.side_effect = AssertionError('21 != 22')\n"
         "    return result\n")
cases = {
    'baseline': text,
    'documented_weakening': text.replace(weakening, 'for row in ():', 1),
    'subject_mock_runtime_assertion': text.replace(insertion, insertion + spoof, 1),
}
fixture_dir = root / 'observations'
fixture_dir.mkdir(exist_ok=True)
spec = importlib.util.spec_from_file_location('native_workspace_mutation_grader', harness)
grader = importlib.util.module_from_spec(spec)
spec.loader.exec_module(grader)
selected = 'NetworkControls.test_network_includes_canonical_historical_commit'
records = []
for mode in ('normal', 'optimized'):
    for name, code in cases.items():
        stem = mode + '-' + name
        candidate = fixture_dir / (stem + '.py')
        event = fixture_dir / (stem + '.json')
        candidate.write_text(code)
        nonce = secrets.token_hex(16)
        env = dict(os.environ, CBZ_VECTOR_UNDER_TEST=str(candidate),
                   CBZ_VECTOR_EVENT=str(event), CBZ_VECTOR_NONCE=nonce)
        command = [sys.executable, '-B', *(['-O'] if mode == 'optimized' else []),
                   '-S', str(harness), '--child', selected]
        proc = subprocess.run(command, env=env, capture_output=True, text=True, timeout=180)
        (fixture_dir / (stem + '.stdout')).write_text(proc.stdout)
        (fixture_dir / (stem + '.stderr')).write_text(proc.stderr)
        event_data = json.loads(event.read_text()) if event.exists() else None
        source_hash = hashlib.sha256(candidate.read_bytes()).hexdigest()
        qualifies = grader.intended_failure(proc, event_data, selected, nonce,
                                             source_hash, '21 != 22')
        rows = event_data.get('failures', []) if isinstance(event_data, dict) else []
        records.append({'mode': mode, 'case': name, 'returncode': proc.returncode,
                        'event_present': event_data is not None,
                        'tests_run': event_data.get('tests_run') if event_data else None,
                        'errors': event_data.get('errors') if event_data else None,
                        'skipped': event_data.get('skipped') if event_data else None,
                        'selected_body': rows[0].get('selected_body') if len(rows) == 1 else None,
                        'classified_kill': qualifies, 'source_sha256': source_hash,
                        'stderr_sha256': hashlib.sha256(proc.stderr.encode()).hexdigest()})
        print(json.dumps(records[-1]), flush=True)
(root / 'results.json').write_text(json.dumps(records, indent=2) + '\n')
expected_results = {'baseline': (0, False), 'documented_weakening': (1, True),
                    'subject_mock_runtime_assertion': (1, False)}
if len(records) != 6 or any((r['returncode'], r['classified_kill']) != expected_results[r['case']]
                            for r in records):
    raise SystemExit('adverse origin criterion failed; see retained observations')
