"""Record exact live traceback provenance of the 13 existing vector mutants."""
import importlib.util
import json
import os
from pathlib import Path
import secrets
import subprocess
import sys

root = Path(__file__).resolve().parent
debug = root / 'diagnostic'
harness = debug / 'tests/test_verify_federation_vector_mutations.py'
source = (root / 'native/tools/verify_federation_vector.py').read_text()
spec = importlib.util.spec_from_file_location('diagnostic_vector_harness', harness)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
out = debug / 'campaign'
out.mkdir(exist_ok=False)
rows = []
for label, before, after, selected, reason in module.MUTANTS:
    if source.count(before) != 1:
        raise ValueError('mutation anchor mismatch: ' + label)
    candidate = out / (label + '.py')
    candidate.write_text(source.replace(before, after, 1))
    event = out / (label + '.json')
    env = dict(os.environ, CBZ_VECTOR_UNDER_TEST=str(candidate), CBZ_VECTOR_EVENT=str(event),
               CBZ_VECTOR_NONCE=secrets.token_hex(16))
    result = subprocess.run([sys.executable, '-B', '-S', str(harness), '--child', selected],
                            env=env, text=True, capture_output=True, timeout=180)
    (out / (label + '.stderr')).write_text(result.stderr)
    event_data = json.loads(event.read_text()) if event.exists() else None
    frames = event_data.get('trace_diagnostic', []) if event_data else []
    rows.append({'label': label, 'selected': selected, 'returncode': result.returncode,
                 'failures': event_data.get('failures') if event_data else None,
                 'reason_present': bool(event_data and reason in event_data['failures'][0]['message']),
                 'frames': frames})
    print(label, result.returncode, flush=True)
(out / 'summary.json').write_text(json.dumps(rows, indent=2) + '\n')
if len(rows) != 13 or any(x['returncode'] != 1 or not x['reason_present'] for x in rows):
    raise SystemExit('diagnostic campaign incomplete')
