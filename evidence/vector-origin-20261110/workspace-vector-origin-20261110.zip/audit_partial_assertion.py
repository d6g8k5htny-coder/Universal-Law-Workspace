"""Exercise a deferred assertion with an otherwise valid oracle-code path."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import secrets
import subprocess
import sys

root = Path(__file__).resolve().parent
native = root / 'native'
harness = native / 'tests/test_verify_federation_vector_mutations.py'
source = (native / 'tools/verify_federation_vector.py').read_text()
anchor = 'def required_remote_commits(snapshot: dict, workspace: dict, locks: dict) -> list[dict]:\n'
if source.count(anchor) != 1:
    raise ValueError('native anchor mismatch')
payload = ("    import functools, unittest\n"
           "    class DeferredLength:\n"
           "        __len__ = functools.partial(unittest.TestCase().assertEqual, 21, 22)\n"
           "    return DeferredLength()\n")
candidate = root / 'observations/subject-partial-runtime-assertion.py'
candidate.write_text(source.replace(anchor, anchor + payload, 1))
spec = importlib.util.spec_from_file_location('native_workspace_mutation_grader', harness)
grader = importlib.util.module_from_spec(spec)
spec.loader.exec_module(grader)
selected = 'NetworkControls.test_network_includes_canonical_historical_commit'
records = []
for mode in ('normal', 'optimized'):
    event = root / ('observations/' + mode + '-subject-partial-runtime-assertion.json')
    nonce = secrets.token_hex(16)
    env = dict(os.environ, CBZ_VECTOR_UNDER_TEST=str(candidate), CBZ_VECTOR_EVENT=str(event),
               CBZ_VECTOR_NONCE=nonce)
    result = subprocess.run([sys.executable, '-B', *(['-O'] if mode == 'optimized' else []),
                             '-S', str(harness), '--child', selected], env=env,
                            text=True, capture_output=True, timeout=180)
    (event.parent / (mode + '-subject-partial-runtime-assertion.stderr')).write_text(result.stderr)
    event_data = json.loads(event.read_text()) if event.exists() else None
    digest = hashlib.sha256(candidate.read_bytes()).hexdigest()
    accepted = grader.intended_failure(result, event_data, selected, nonce, digest, '21 != 22')
    rows = event_data.get('failures', []) if event_data else []
    records.append({'mode': mode, 'returncode': result.returncode,
                    'selected_body': rows[0].get('selected_body') if len(rows) == 1 else None,
                    'classified_kill': accepted, 'source_sha256': digest,
                    'stderr_sha256': hashlib.sha256(result.stderr.encode()).hexdigest()})
    print(json.dumps(records[-1]), flush=True)
(root / 'partial-results.json').write_text(json.dumps(records, indent=2) + '\n')
if len(records) != 2 or any(r['returncode'] != 1 or r['classified_kill'] for r in records):
    raise SystemExit('adverse origin criterion failed; see retained observations')
