"""Record bytecode positions from live traceback objects for four real cases."""
import json
import os
from pathlib import Path
import secrets
import shutil
import subprocess
import sys

root = Path(__file__).resolve().parent
native = root / 'native'
debug = root / 'diagnostic'
if debug.exists():
    raise SystemExit('diagnostic directory already exists; preserve it')
shutil.copytree(native, debug)
harness = debug / 'tests/test_verify_federation_vector_mutations.py'
text = harness.read_text()
needle = "        def addFailure(self, case, error):\n            record['failures'].append(dict(selected_body=failure_origin(error, selected), message=str(error[1])))\n"
replacement = '''        def addFailure(self, case, error):
            import dis
            trace = error[2]
            frames = []
            while trace:
                frame = trace.tb_frame
                ins = next((i for i in dis.get_instructions(frame.f_code, show_caches=True) if i.offset == trace.tb_lasti), None)
                pos = ins.positions if ins else None
                frames.append({'name': frame.f_code.co_qualname, 'filename': frame.f_code.co_filename,
                    'lasti': trace.tb_lasti, 'opname': ins.opname if ins else None,
                    'position': [pos.lineno, pos.end_lineno, pos.col_offset, pos.end_col_offset] if pos else None})
                trace = trace.tb_next
            record['trace_diagnostic'] = frames
            record['failures'].append(dict(selected_body=failure_origin(error, selected), message=str(error[1])))
'''
if text.count(needle) != 1:
    raise ValueError('diagnostic insertion mismatch')
harness.write_text(text.replace(needle, replacement, 1))
source = (native / 'tools/verify_federation_vector.py').read_text()
replace = 'set(values) == set(REPOSITORIES)'
if source.count(replace) != 1:
    raise ValueError('vector mutation anchor mismatch')
cases = [
    ('direct-assert', root / 'observations/normal-documented_weakening.py',
     'NetworkControls.test_network_includes_canonical_historical_commit'),
    ('with-exit', debug / 'vector-set.py', 'VectorSources.test_vector_omission_rejected'),
    ('mock-side-effect', root / 'observations/normal-subject_mock_runtime_assertion.py',
     'NetworkControls.test_network_includes_canonical_historical_commit'),
    ('case-deferred', root / 'observations/subject-case-runtime-assertion.py',
     'NetworkControls.test_network_includes_canonical_historical_commit'),
]
(debug / 'vector-set.py').write_text(source.replace(replace, 'True', 1))
results = []
for name, candidate, selected in cases:
    event = debug / (name + '.json')
    env = dict(os.environ, CBZ_VECTOR_UNDER_TEST=str(candidate), CBZ_VECTOR_EVENT=str(event),
               CBZ_VECTOR_NONCE=secrets.token_hex(16))
    process = subprocess.run([sys.executable, '-B', '-S', str(harness), '--child', selected],
                             env=env, text=True, capture_output=True, timeout=180)
    (debug / (name + '.stderr')).write_text(process.stderr)
    record = json.loads(event.read_text())
    results.append({'case': name, 'returncode': process.returncode,
                    'selected_body': record['failures'][0]['selected_body'],
                    'frames': record['trace_diagnostic']})
(debug / 'trace-summary.json').write_text(json.dumps(results, indent=2) + '\n')
print(json.dumps(results, indent=2))
