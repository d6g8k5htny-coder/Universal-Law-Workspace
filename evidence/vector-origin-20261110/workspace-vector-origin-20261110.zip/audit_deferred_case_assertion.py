"""Test a second subject-origin assertion deferred into unittest.case."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import secrets
import subprocess
import sys

root = Path(__file__).resolve().parent
native = root / 'native'
harness = native / 'tests/test_verify_federation_vector_mutations.py'
source = native / 'tools/verify_federation_vector.py'
text = source.read_text()
anchor = 'def required_remote_commits(snapshot: dict, workspace: dict, locks: dict) -> list[dict]:\n'
if text.count(anchor) != 1:
    raise ValueError('native anchor mismatch')
payload = ("    import unittest\n"
           "    class DeferredLength:\n"
           "        __len__ = unittest.TestCase.fail\n"
           "        @staticmethod\n"
           "        def failureException(message):\n"
           "            return AssertionError('21 != 22')\n"
           "    return DeferredLength()\n")
folder = root / 'observations'
folder.mkdir(exist_ok=True)
candidate = folder / 'subject-case-runtime-assertion.py'
candidate.write_text(text.replace(anchor, anchor + payload, 1))
spec = importlib.util.spec_from_file_location('native_workspace_mutation_grader', harness)
grader = importlib.util.module_from_spec(spec)
spec.loader.exec_module(grader)
selected = 'NetworkControls.test_network_includes_canonical_historical_commit'
result = []
for mode in ('normal', 'optimized'):
    event = folder / (mode + '-subject-case-runtime-assertion.json')
    nonce = secrets.token_hex(16)
    env = dict(os.environ, CBZ_VECTOR_UNDER_TEST=str(candidate),
               CBZ_VECTOR_EVENT=str(event), CBZ_VECTOR_NONCE=nonce)
    process = subprocess.run([sys.executable, '-B', *(['-O'] if mode == 'optimized' else []),
                              '-S', str(harness), '--child', selected],
                             env=env, capture_output=True, text=True, timeout=180)
    (folder / (mode + '-subject-case-runtime-assertion.stdout')).write_text(process.stdout)
    (folder / (mode + '-subject-case-runtime-assertion.stderr')).write_text(process.stderr)
    event_data = json.loads(event.read_text()) if event.exists() else None
    digest = hashlib.sha256(candidate.read_bytes()).hexdigest()
    accepted = grader.intended_failure(process, event_data, selected, nonce, digest, '21 != 22')
    rows = event_data.get('failures', []) if isinstance(event_data, dict) else []
    result.append({'mode': mode, 'returncode': process.returncode,
                   'tests_run': event_data.get('tests_run') if event_data else None,
                   'errors': event_data.get('errors') if event_data else None,
                   'skipped': event_data.get('skipped') if event_data else None,
                   'selected_body': rows[0].get('selected_body') if len(rows) == 1 else None,
                   'classified_kill': accepted, 'source_sha256': digest,
                   'stderr_sha256': hashlib.sha256(process.stderr.encode()).hexdigest()})
    print(json.dumps(result[-1]), flush=True)
(root / 'deferred-case-results.json').write_text(json.dumps(result, indent=2) + '\n')
if len(result) != 2 or any(r['returncode'] != 1 or r['classified_kill'] for r in result):
    raise SystemExit('adverse origin criterion failed; see retained observations')
