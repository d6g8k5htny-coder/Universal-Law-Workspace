"""Verify retained local finite campaign members and cross-mode identities."""
import hashlib
import json
from pathlib import Path
import re

root = Path(__file__).resolve().parent
rows_by_key = {}
nonces = set()
result = {}
for mode in ('normal', 'optimized'):
    campaigns = list((root / ('campaign-v3-' + mode)).glob('campaign-*'))
    if len(campaigns) != 1:
        raise ValueError('expected one retained campaign: ' + mode)
    folder = campaigns[0]
    entries = json.loads((folder / 'summary.json').read_text())
    if len(entries) != 26:
        raise ValueError('unexpected campaign population: ' + mode)
    for row in entries:
        key = (mode, row['mutation'], row['kind'])
        if key in rows_by_key or row['kind'] not in ('baseline', 'mutant'):
            raise ValueError('duplicate or invalid campaign record')
        stem = row['mutation'] + '-' + row['kind']
        source = (folder / (stem + '.py')).read_bytes()
        stderr = (folder / (stem + '.stderr')).read_bytes()
        (folder / (stem + '.stdout')).read_bytes()
        event = json.loads((folder / (stem + '.json')).read_text())
        digest = hashlib.sha256(source).hexdigest()
        if digest != row['source_sha256'] or event['source_before'] != digest or event['source_after'] != digest:
            raise ValueError('candidate source mismatch: ' + stem)
        if hashlib.sha256(stderr).hexdigest() != row['stderr_sha256']:
            raise ValueError('stderr mismatch: ' + stem)
        if event['test'] != row['test'] or event['tests_run'] != 1 or any(
                event[name] != 0 for name in ('errors', 'skipped', 'expected_failures', 'unexpected_successes')):
            raise ValueError('invalid event counts or selected test: ' + stem)
        nonce = event['nonce']
        if not isinstance(nonce, str) or not re.fullmatch('[0-9a-f]{32}', nonce) or nonce in nonces:
            raise ValueError('invalid or repeated event nonce')
        nonces.add(nonce)
        if row['kind'] == 'baseline':
            if row['exit_code'] != 0 or event['failures']:
                raise ValueError('baseline failed: ' + stem)
        elif row['exit_code'] != 1 or len(event['failures']) != 1 or event['failures'][0]['selected_body'] is not True:
            raise ValueError('mutant outcome differs: ' + stem)
        rows_by_key[key] = digest
    labels = {row['mutation'] for row in entries}
    if len(labels) != 13 or any((mode, label, kind) not in rows_by_key for label in labels for kind in ('baseline', 'mutant')):
        raise ValueError('mutation pair coverage mismatch: ' + mode)
    result[mode] = {'pairs': len(labels), 'events': len(entries)}
labels = {key[1] for key in rows_by_key}
for label in labels:
    for kind in ('baseline', 'mutant'):
        if rows_by_key[('normal', label, kind)] != rows_by_key[('optimized', label, kind)]:
            raise ValueError('cross-mode candidate mismatch: ' + label)
    if rows_by_key[('normal', label, 'baseline')] == rows_by_key[('normal', label, 'mutant')]:
        raise ValueError('baseline and mutant bytes identical: ' + label)
result.update({'unique_nonces': len(nonces), 'source_and_stderr_hashes': 'matched',
               'scope': 'finite local component observations; not full federation G6 or scientific review'})
(root / 'campaign-v3-verification.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
